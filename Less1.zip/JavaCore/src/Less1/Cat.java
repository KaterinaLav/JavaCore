package Less1;

public class Cat extends Animal {
    public Cat(String name) {
        super("Коты", name, 200, 20, 2);
    }
}
