package Less1;

public class Dog extends Animal {
    public Dog(String name) {
        super("Собаки", name, 300, 40, 4);
    }
}